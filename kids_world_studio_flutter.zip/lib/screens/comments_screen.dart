import 'package:flutter/material.dart';

class CommentsScreen extends StatelessWidget {
  const CommentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final comments = [
      ('Sarah Khan', 'My child loved this video ❤️'),
      ('Ayesha Malik', 'Very nice video. Please make more ABC videos.'),
      ('Ali Raza', 'Amazing content for kids 👏'),
      ('Mehwish A.', 'Can you make videos on shapes and colors?'),
    ];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Comments', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          Wrap(spacing: 8, children: const [
            Chip(label: Text('All 325')),
            Chip(label: Text('Unread 24')),
            Chip(label: Text('Replied')),
            Chip(label: Text('Spam')),
          ]),
          const SizedBox(height: 10),
          for (final c in comments)
            Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(c.$2),
                  const SizedBox(height: 10),
                  Row(children: [
                    FilledButton.tonal(onPressed: () {}, child: const Text('Reply')),
                    const SizedBox(width: 8),
                    TextButton(onPressed: () {}, child: const Text('Like')),
                    TextButton(onPressed: () {}, child: const Text('Hide')),
                  ]),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}
