import 'package:flutter/material.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final videos = [
      ('Funny Baby Learning Colors', '25.4K views • 1 day ago'),
      ('Learn Animals Names & Sounds', '32.1K views • 3 days ago'),
      ('123 Numbers Song for Kids', '18.7K views • 5 days ago'),
      ('Fruits Names for Children', '14.2K views • 1 week ago'),
    ];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Videos', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Published')),
              ButtonSegment(value: 1, label: Text('Scheduled')),
              ButtonSegment(value: 2, label: Text('Drafts')),
            ],
            selected: const {0},
            onSelectionChanged: (_) {},
          ),
          const SizedBox(height: 14),
          for (final v in videos)
            Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Row(children: [
                      Container(width: 100, height: 65, decoration: BoxDecoration(color: const Color(0xFFE4DEFF), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.video_library, color: Color(0xFF6C4DFF), size: 32)),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(v.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 5),
                        Text(v.$2, style: const TextStyle(color: Colors.grey)),
                      ])),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: OutlinedButton(onPressed: () {}, child: const Text('Analytics'))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton(onPressed: () {}, child: const Text('Edit'))),
                    ]),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
