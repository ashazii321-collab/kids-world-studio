import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget stat(String title, String value, IconData icon) {
    return Expanded(
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: const Color(0xFF6C4DFF)),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 3),
              Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Kids World Studio', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('YouTube Channel Manager', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF6C4DFF), Color(0xFF8E75FF)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Good afternoon! 👋', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text("Here's what's happening with Kids World.", style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
                Text('🧸', style: TextStyle(fontSize: 54)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(children: [stat('Subscribers', '12.5K', Icons.people), stat('Views', '1.2M', Icons.visibility)]),
          Row(children: [stat('Watch Time', '45.6K', Icons.access_time), stat('Revenue', '\$245', Icons.attach_money)]),
          const SizedBox(height: 18),
          const Text('Recent Videos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          for (final item in [
            ['Learn Colors with Cute Baby 🌈', '25.4K views • 1 day ago'],
            ['ABC Learning for Toddlers', '18.7K views • 3 days ago'],
            ['Baby Animals for Kids', '14.2K views • 1 week ago'],
          ])
            Card(
              elevation: 0,
              child: ListTile(
                leading: Container(
                  width: 64, height: 46,
                  decoration: BoxDecoration(color: const Color(0xFFE4DEFF), borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.play_circle_fill, color: Color(0xFF6C4DFF)),
                ),
                title: Text(item[0], style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(item[1]),
              ),
            ),
        ],
      ),
    );
  }
}
