import 'package:flutter/material.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Analytics', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('7D')),
              ButtonSegment(value: 1, label: Text('28D')),
              ButtonSegment(value: 2, label: Text('90D')),
              ButtonSegment(value: 3, label: Text('365D')),
            ],
            selected: const {1},
            onSelectionChanged: (_) {},
          ),
          const SizedBox(height: 18),
          Row(children: [
            metric('Views', '125.4K'),
            metric('Watch Time', '4.6K'),
            metric('Subscribers', '+1.2K'),
          ]),
          const SizedBox(height: 18),
          Card(
            elevation: 0,
            child: SizedBox(
              height: 230,
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Views Over Time', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(12, (i) => Container(
                      width: 14,
                      height: 30.0 + (i % 5) * 24,
                      decoration: BoxDecoration(color: const Color(0xFF6C4DFF), borderRadius: BorderRadius.circular(8)),
                    )),
                  ),
                  const SizedBox(height: 12),
                  const Text('Aug 4                 Aug 10', style: TextStyle(color: Colors.grey)),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Top Videos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const ListTile(title: Text('ABC Learning for Toddlers'), trailing: Text('125K')),
          const ListTile(title: Text('Learn Colors with Cute Baby'), trailing: Text('98K')),
          const ListTile(title: Text('Baby Animals for Kids'), trailing: Text('76K')),
        ],
      ),
    );
  }

  Widget metric(String title, String value) => Expanded(
    child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Text(title, style: const TextStyle(fontSize: 11)),
      const SizedBox(height: 5),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    ]))),
  );
}
